#ifndef EXTRAER_H
#define EXTRAER_H

/**************************************************
 * Fecha: 02-03-2022
 * Autor: Diego Bermúdez
 * Materia: HPC-1
 * Tema: Construcción de interfaz de la clase extraer
 * Objetivo:
 * 1.- Crear una clase que permita la manipulación
 * de los datos (extracción, normalización).
* **************************************************/

#include <iostream>
#include <fstream>
#include <eigen3/Eigen/Dense>
#include <vector>


class Extraer
{
    /* Se presenta el constructor de los argumentos
    *  de entrada a la clase
    *  Extraer*/
    // Nombre del dataset
    std::string setDatos;
    // Separador de columnas
    std::string delimitador;
    // Si tiene cabecera o no, el dataset
    bool header;

public:
   Extraer(std::string datos,
           std::string separador,
           bool head):
       setDatos(datos),
       delimitador(separador),
       header(head){}


   std::vector<std::vector<std::string>> ReadCSV();
   Eigen::MatrixXd CSVtoEigen(
          std::vector<std::vector<std::string>> SETdatos,
          int filas, int columnas);
};

#endif // EXTRAER_H
