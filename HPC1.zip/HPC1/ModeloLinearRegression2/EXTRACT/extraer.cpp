/**************************************************
 * Fecha: 02-03-2022
 * Autor: Diego Bermúdez
 * Materia: HPC-1
 * Tema: Construcción del algoritmo para Regresión Lineal con EIGEN
 * Objetivo:
 * Implementación de la clase extraer
 * 1.- Crear una clase que permita la manipulación
 * de los datos (extracción, normalización).
* **************************************************/

#include "extraer.h"
#include <iostream>
#include <fstream>//CSV
#include <eigen3/Eigen/Dense>
#include <vector>
#include <boost/algorithm/string.hpp>

/* Primer función miembro: lectura de fichero csv.
 * Se presenta como un vector de vectores del tipo string
 * La idea es leer linea por linea y almacenar
 * cada una un vector de vectores del tipo string.
 * */

std::vector<std::vector<std::string>> Extraer::ReadCSV(){
    // Abrir el fichero para lectura solamente
    std::fstream Fichero(setDatos);//setDatos

    // Vector de vectores string a entregar por
    // parte de la función
    std::vector<std::vector<std::string>> datosString;
    /* Se itera a traves de cada linea, y se divide el contenido
     * dado por el separador provisto por el constructor
    */
    // Almacenar cada linea
    std::string linea = "";
    while(getline(Fichero, linea)){
        // Se crea un vector para almacenar la fila
        std::vector<std::string> vectorFila;
        // Se separa segun el limitador
        boost::algorithm::split(vectorFila,
                                linea,
                                boost::is_any_of(delimitador));
        datosString.push_back(vectorFila);
    }
    // Se cierra el fichero .csv
    Fichero.close();
    // Se retorna el vector de vectores de tipo string
    return datosString;
}
/* Se implementa la segunda función miembro, la cual tiene como misión
 * transformar el vector de vectores del tipo string,
 * en una matrix Eigen. La idea es simular un objeto DATAFRAME de pandas,
 * para poder manipular los datos.*/
Eigen::MatrixXd Extraer::CSVtoEigen(
       std::vector<std::vector<std::string>> SETdatos,
       int filas, int columnas){
        /* Se hace la pregunta si tiene cabecera o no el vector
         * de vectores del tipo string.
         * Si tiene cabecera, se debe eliminar*/
        if(header==true)
        {
            filas = filas - 1;
        }
        /* Se itera sobre cada registro del fichero,
         * a la vez que se almacena en una matrixXd,
         * de dimensión filas por columnas. Principalmente,
         * almacenará strings (porque llega un vector de
         * vectores del tipo string. La idea es
         * hacer un casting de string a float.*/
      Eigen::MatrixXd MatrizDF(columnas,filas);
      for(int i=0;i<filas;i++)
      {
          for(int j=0;j<columnas;j++)
          {
              MatrizDF(j,i) = atof(SETdatos[i][j].c_str());
          }
      }
      /* Se transpone la matriz, dado que viene por columnas
       * por filas, para retornarla.*/
      return MatrizDF.transpose();

}
