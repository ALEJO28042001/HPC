/**************************************************
 * Fecha: 28-02-2022
 * Autor: Diego Bermúdez
 * Materia: HPC-1
 * Tema: Repaso Algebra Lineal con EIGEN
* **************************************************/

#include <iostream>
#include <eigen3/Eigen/Dense>

using namespace std;

//Se declara un tipo de dato matrix 3x3
typedef Eigen::Matrix<int,3,3> MiMatrix33F;
typedef Eigen::Matrix3d MiMatrix33D;



int main()
{
    MiMatrix33D p,q;
    p <<MiMatrix33D::Random();
    q <<4,2,-2,0,5,7,8,1,4;
    //Se declaran 2 matrices 3x3 double
    cout<<"\n********* Aritmetica con Matrices********"<<endl;
    cout<<"La matriz p: \n"<<p<<endl;
    cout<<"La matriz q: \n"<<q<<endl;
    cout<<"La matriz p+q: \n"<<p+q<<endl;
    cout<<"La matriz p-q: \n"<<p-q<<endl;
    cout<<"\n********* Matrices con vectores ********"<<endl;
    Eigen::Vector3d r(100,200,20);
    Eigen::Vector3d s(0,100,-40);
    cout<<"El vector r: \n"<<r<<endl;
    cout<<"El vector s: \n"<<s<<endl;
    cout<<"Matrix p por vector r: \n"<<p*r<<endl;
    cout<<"Producto punto (.) entre r y s <vectores> \n"<<p*r<<endl;
    cout<<"Producto cruz (x) entre r y s <vectores> \n"<<p<<endl;


    cout<<"\n\n **********Operaciones de reducción **************"<<endl;
    cout<<"La matriz p: \n"<<p<<endl;
    cout<<"Operación suma p reducción: \n"<<p.sum()<<endl;
    cout<<"Operación producto p reducción: \n"<<p.prod()<<endl;
    cout<<"Operación mean p reducción: \n"<<p.mean()<<endl;
    cout<<"Operación minCoeff p reducción: \n"<<p.minCoeff()<<endl;
    cout<<"Operación maxCoeff p reducción: \n"<<p.maxCoeff()<<endl;
    cout<<"Operación trace p reducción: \n"<<p.trace()<<endl;


    cout<<"\n\n\n\n";
}
